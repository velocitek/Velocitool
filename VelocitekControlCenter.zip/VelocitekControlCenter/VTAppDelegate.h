#import <Cocoa/Cocoa.h>

@class VTDeviceLoader;
@class MainWindowController;

@interface VTAppDelegate : NSObject 
{    
 	
    VTDeviceLoader *_loader;
    MainWindowController *mainWindowController;
	
}




@end
