
#import <Cocoa/Cocoa.h>
#import "ftd2xx.h"

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
