//
//  TrackpointLogRecord.h
//  Velocitool
//
//  Created by Alec Stewart on 3/14/10.
//  Copyright 2010 Velocitek. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TrackpointLogRecord : NSObject {
	
	private const int BODY_LENGTH_IN_BYTES = 19;

}

@end
