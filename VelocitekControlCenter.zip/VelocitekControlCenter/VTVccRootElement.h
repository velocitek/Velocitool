//
//  VTVccRootElement.h
//  Velocitool
//
//  Created by Alec Stewart on 6/6/10.
//  Copyright 2010 Velocitek. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface VTVccRootElement : NSXMLElement {

}

+ (id)generateVccRootElement;

- (id)initRootElement;

@end
