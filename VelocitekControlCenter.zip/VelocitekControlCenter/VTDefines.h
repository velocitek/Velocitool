//
//  VTDefines.h
//  Velocitool
//
//  Created by Dev Mac on 8/15/16.
//
//

#import <Foundation/Foundation.h>

#define kErrorIncompatibleMessage @"This version of Velocitek Control Center is not compatible with the detected operating system."

@interface VTDefines : NSObject

@end
