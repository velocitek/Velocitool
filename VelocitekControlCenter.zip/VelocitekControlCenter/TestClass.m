//
//  TestClass.m
//  Velocitool
//
//  Created by Alec Stewart on 5/1/10.
//  Copyright 2010 Velocitek. All rights reserved.
//

#import "TestClass.h"


@implementation TestClass

- init
{
	[super init];	
	NSLog(@"Instance of test class initialized");
	return self;
}

@end
