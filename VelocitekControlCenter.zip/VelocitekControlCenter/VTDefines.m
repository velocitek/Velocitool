//
//  VTDefines.m
//  Velocitool
//
//  Created by Dev Mac on 8/15/16.
//
//

#import "VTDefines.h"

@implementation VTDefines

@end
